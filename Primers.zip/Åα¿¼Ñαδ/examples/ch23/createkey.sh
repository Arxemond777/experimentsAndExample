
keytool -genkey -alias Pat -keyalg DSA -keysize 1024 -dname "CN=Pat Niemeyer, OU=Technical Publications, O=O'Reilly & Associates, C=US" -keypass secure -storepass access

