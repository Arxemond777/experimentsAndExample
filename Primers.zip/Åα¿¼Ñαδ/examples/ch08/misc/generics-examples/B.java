import java.util.*;
/**
	
	@author Pat Niemeyer (pat@pat.net)
*/
public class B 
{
	public static void main( String [] args )
	{
		List<E extends Date> dl = new ArrayList<E extends Date>();
	}

}
