import java.util.*;

/**
	
	@author Pat Niemeyer (pat@pat.net)
*/
public class Arrays 
{
	public static void main( String [] args )
	{
		List<?>[] lsa = new ArrayList[10];
	}

}
