import java.util.*;
public class T1<T extends Date>
{
	
	List<? extends Date & Runnable> l1;

}
