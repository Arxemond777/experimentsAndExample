/**
	
	@author Pat Niemeyer (pat@pat.net)
*/
import java.util.*;

public class Generics1 
{
	public static void main( String [] args )
	{
		ArrayList<String> als = new ArrayList();
	}

}
