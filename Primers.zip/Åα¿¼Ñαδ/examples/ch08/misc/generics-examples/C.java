import java.util.*;

public class C 
{
	void printCollection( Collection c ) {
		for( Object e: c )
			System.out.println(e);
	}

}
