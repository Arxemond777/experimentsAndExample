import java.util.*;

public class GenericMethods2 
{
	/*
	static <T> List<T> arrayToList( Object [] oa ) {
		List<T> lt = new ArrayList<T>();
		for( Object o : oa )
			lt.add( o );
		return lt;
	}
	*/

	static <T> T foo() { }

	public static void main( String [] args )
	{
	}

}
