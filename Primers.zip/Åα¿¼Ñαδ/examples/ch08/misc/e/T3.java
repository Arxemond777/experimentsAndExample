public class T3 
{
	<?> void foo( T t ) { }

	public static void main( String [] args )
	{
	}

}
