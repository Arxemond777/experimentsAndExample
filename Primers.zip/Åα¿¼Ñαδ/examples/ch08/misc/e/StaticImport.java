import java.util.*;
import Q;
import static Q.*;

public class StaticImport 
{

	public static void main( String [] args )
	{
		System.out.println( Q.class );
	}

}
