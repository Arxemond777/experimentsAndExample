import java.util.*;

public class Raw 
{

	@SuppressWarnings(value={"unchecked"})
	public static void main( String [] args )
	{
		List list = new ArrayList();
		list.add("foo");
	}

}
