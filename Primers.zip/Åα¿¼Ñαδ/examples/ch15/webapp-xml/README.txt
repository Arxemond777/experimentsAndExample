
This directory contains an Ant build file that will create the example
WAR file.

To compile these classes requires that javax.servlet standard extension
package be added to your classpath.  You can find the servlet.jar file
in the Tomcat distribution under the path <tomcat>/common/lib/servlet.jar
or you can download it from http://java.sun.com/servlet/

Or you can compile the files and construct the WAR manually, following
the instructions in the book.

