import java.util.*;

public class T1 < 
{
	private static void print( Object o ) { System.out.println(o); }
	private static void print( long o ) { System.out.println(o); }
	private static void print( double o ) { System.out.println(o); }
	private static long time() { return System.currentTimeMillis(); }

	public static void main( String [] args )
	{
	}

}
