
This directory contains two copies of the Learning Java source code packaged for eclipse.  The difference is that the "Appendix A" version contains a "Learning Java" folder and the "Chapter 2" version has the contents at the top level of the zip file.  We apologize for the necessity of the two versions; the loading instructions in each chapter are slightly different and will be reconciled in a future update.

Files
-----

examples-eclipse-ch2.zip  -- Use this file if you start with Chapter 2 and import after you create your own project.
examples-eclipse-appa.zip -- Use this file if you start with Appendix A and import directly from the archive (ZIP).


