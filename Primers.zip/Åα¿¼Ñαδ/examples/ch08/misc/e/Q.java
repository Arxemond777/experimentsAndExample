
public final class Q 
{
	public static final int A=1;
	public static final int B=2;
}
